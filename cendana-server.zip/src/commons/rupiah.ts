export function rupiah(x: number) {
  return x.toLocaleString('id')
}