export type TotalResult = [{
  total: number
}]