import { FastifyRequest, FastifyReply } from 'fastify'
import * as DTO from './user.dto';

export async function post() {

}