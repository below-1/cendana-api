export class NoAuthHeader extends Error {
}

export class InvalidToken extends Error {
}

export class UserNotFound extends Error {
}
