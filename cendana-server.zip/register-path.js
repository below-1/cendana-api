const moduleAlias = require('module-alias')
 
//
// Register alias
//
moduleAlias.addAlias('@client', __dirname + '/src')
